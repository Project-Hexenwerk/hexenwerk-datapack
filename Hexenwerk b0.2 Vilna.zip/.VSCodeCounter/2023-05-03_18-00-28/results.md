# Summary

Date : 2023-05-03 18:00:28

Directory c:\\Users\\Flynn\\AppData\\Roaming\\.minecraft\\saves\\Hexenwerk Dev\\datapacks\\Hexenwerk Datapack

Total : 343 files,  4511 codes, 59 comments, 585 blanks, all 5155 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JSON | 120 | 2,830 | 0 | 91 | 2,921 |
| mcfunction | 223 | 1,681 | 59 | 494 | 2,234 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 343 | 4,511 | 59 | 585 | 5,155 |
| . (Files) | 1 | 21 | 0 | 0 | 21 |
| data | 342 | 4,490 | 59 | 585 | 5,134 |
| data\\hexenwerk | 332 | 3,574 | 59 | 578 | 4,211 |
| data\\hexenwerk\\advancements | 11 | 250 | 0 | 5 | 255 |
| data\\hexenwerk\\advancements (Files) | 6 | 187 | 0 | 0 | 187 |
| data\\hexenwerk\\advancements\\craft | 3 | 42 | 0 | 3 | 45 |
| data\\hexenwerk\\advancements\\other | 2 | 21 | 0 | 2 | 23 |
| data\\hexenwerk\\damage_type | 3 | 17 | 0 | 3 | 20 |
| data\\hexenwerk\\functions | 223 | 1,681 | 59 | 494 | 2,234 |
| data\\hexenwerk\\functions (Files) | 7 | 150 | 24 | 33 | 207 |
| data\\hexenwerk\\functions\\amulets | 1 | 0 | 0 | 1 | 1 |
| data\\hexenwerk\\functions\\animations | 1 | 3 | 0 | 0 | 3 |
| data\\hexenwerk\\functions\\armor_modifiers | 5 | 13 | 0 | 1 | 14 |
| data\\hexenwerk\\functions\\blocks | 86 | 771 | 15 | 168 | 954 |
| data\\hexenwerk\\functions\\blocks (Files) | 3 | 20 | 0 | 8 | 28 |
| data\\hexenwerk\\functions\\blocks\\dev_desk | 8 | 49 | 0 | 14 | 63 |
| data\\hexenwerk\\functions\\blocks\\dev_desk (Files) | 4 | 14 | 0 | 11 | 25 |
| data\\hexenwerk\\functions\\blocks\\dev_desk\\blocks | 1 | 5 | 0 | 0 | 5 |
| data\\hexenwerk\\functions\\blocks\\dev_desk\\home | 1 | 3 | 0 | 0 | 3 |
| data\\hexenwerk\\functions\\blocks\\dev_desk\\items | 1 | 11 | 0 | 1 | 12 |
| data\\hexenwerk\\functions\\blocks\\dev_desk\\spells | 1 | 16 | 0 | 2 | 18 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table | 70 | 683 | 15 | 136 | 834 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table (Files) | 3 | 16 | 0 | 19 | 35 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\gui | 8 | 212 | 0 | 30 | 242 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\gui (Files) | 1 | 3 | 0 | 3 | 6 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\gui\\check_extra | 3 | 195 | 0 | 18 | 213 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\gui\\mask | 4 | 14 | 0 | 9 | 23 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\magical | 29 | 175 | 15 | 37 | 227 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\magical (Files) | 4 | 69 | 15 | 21 | 105 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\magical\\craft | 25 | 106 | 0 | 16 | 122 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\magical\\craft (Files) | 15 | 60 | 0 | 14 | 74 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\magical\\craft\\remove_output | 10 | 46 | 0 | 2 | 48 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\magical\\craft\\remove_output (Files) | 1 | 19 | 0 | 0 | 19 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\magical\\craft\\remove_output\\substract | 9 | 27 | 0 | 2 | 29 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\switch_mode | 4 | 97 | 0 | 22 | 119 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\switch_mode (Files) | 2 | 7 | 0 | 11 | 18 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\switch_mode\\remove_items | 2 | 90 | 0 | 11 | 101 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\wand | 26 | 183 | 0 | 28 | 211 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\wand (Files) | 3 | 19 | 0 | 4 | 23 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\wand\\apply | 11 | 80 | 0 | 15 | 95 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\wand\\apply (Files) | 6 | 45 | 0 | 7 | 52 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\wand\\apply\\remove | 5 | 35 | 0 | 8 | 43 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\wand\\load_books | 12 | 84 | 0 | 9 | 93 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\wand\\load_books (Files) | 6 | 51 | 0 | 6 | 57 |
| data\\hexenwerk\\functions\\blocks\\magical_crafting_table\\wand\\load_books\\kick_items | 6 | 33 | 0 | 3 | 36 |
| data\\hexenwerk\\functions\\blocks\\magical_flower | 2 | 5 | 0 | 7 | 12 |
| data\\hexenwerk\\functions\\blocks\\spell_blocker | 3 | 14 | 0 | 3 | 17 |
| data\\hexenwerk\\functions\\config | 15 | 35 | 0 | 30 | 65 |
| data\\hexenwerk\\functions\\config\\mana_max | 5 | 15 | 0 | 10 | 25 |
| data\\hexenwerk\\functions\\config\\mana_regen | 5 | 10 | 0 | 10 | 20 |
| data\\hexenwerk\\functions\\config\\max_raycast_distance | 5 | 10 | 0 | 10 | 20 |
| data\\hexenwerk\\functions\\craft | 3 | 12 | 0 | 17 | 29 |
| data\\hexenwerk\\functions\\dev | 6 | 33 | 0 | 1 | 34 |
| data\\hexenwerk\\functions\\dev\\dev_stone | 6 | 33 | 0 | 1 | 34 |
| data\\hexenwerk\\functions\\dev\\dev_stone (Files) | 1 | 4 | 0 | 0 | 4 |
| data\\hexenwerk\\functions\\dev\\dev_stone\\swap_spell | 2 | 14 | 0 | 0 | 14 |
| data\\hexenwerk\\functions\\dev\\dev_stone\\switch | 3 | 15 | 0 | 1 | 16 |
| data\\hexenwerk\\functions\\mana | 8 | 72 | 0 | 5 | 77 |
| data\\hexenwerk\\functions\\spell_events | 30 | 245 | 2 | 57 | 304 |
| data\\hexenwerk\\functions\\spell_events (Files) | 1 | 10 | 0 | 2 | 12 |
| data\\hexenwerk\\functions\\spell_events\\end | 6 | 37 | 0 | 15 | 52 |
| data\\hexenwerk\\functions\\spell_events\\other | 1 | 3 | 0 | 1 | 4 |
| data\\hexenwerk\\functions\\spell_events\\start | 10 | 102 | 0 | 15 | 117 |
| data\\hexenwerk\\functions\\spell_events\\start (Files) | 7 | 78 | 0 | 12 | 90 |
| data\\hexenwerk\\functions\\spell_events\\start\\display_entities | 3 | 24 | 0 | 3 | 27 |
| data\\hexenwerk\\functions\\spell_events\\start\\display_entities\\consedo | 3 | 24 | 0 | 3 | 27 |
| data\\hexenwerk\\functions\\spell_events\\while | 12 | 93 | 2 | 24 | 119 |
| data\\hexenwerk\\functions\\spell_events\\while (Files) | 6 | 53 | 2 | 15 | 70 |
| data\\hexenwerk\\functions\\spell_events\\while\\commovus_motus | 2 | 4 | 0 | 2 | 6 |
| data\\hexenwerk\\functions\\spell_events\\while\\terrae_motus | 4 | 36 | 0 | 7 | 43 |
| data\\hexenwerk\\functions\\spell_events\\while\\terrae_motus (Files) | 1 | 2 | 0 | 1 | 3 |
| data\\hexenwerk\\functions\\spell_events\\while\\terrae_motus\\waves | 3 | 34 | 0 | 6 | 40 |
| data\\hexenwerk\\functions\\triggers | 5 | 25 | 0 | 10 | 35 |
| data\\hexenwerk\\functions\\triggers (Files) | 4 | 17 | 0 | 6 | 23 |
| data\\hexenwerk\\functions\\triggers\\click_events | 1 | 8 | 0 | 4 | 12 |
| data\\hexenwerk\\functions\\triggers\\click_events\\settings | 1 | 8 | 0 | 4 | 12 |
| data\\hexenwerk\\functions\\update | 2 | 4 | 0 | 1 | 5 |
| data\\hexenwerk\\functions\\update\\wand | 2 | 4 | 0 | 1 | 5 |
| data\\hexenwerk\\functions\\utility | 3 | 8 | 0 | 3 | 11 |
| data\\hexenwerk\\functions\\wand | 51 | 310 | 18 | 167 | 495 |
| data\\hexenwerk\\functions\\wand (Files) | 6 | 51 | 0 | 20 | 71 |
| data\\hexenwerk\\functions\\wand\\slot_1 | 2 | 15 | 2 | 17 | 34 |
| data\\hexenwerk\\functions\\wand\\slot_2 | 2 | 15 | 2 | 14 | 31 |
| data\\hexenwerk\\functions\\wand\\slot_3 | 2 | 15 | 2 | 13 | 30 |
| data\\hexenwerk\\functions\\wand\\slot_4 | 2 | 15 | 2 | 13 | 30 |
| data\\hexenwerk\\functions\\wand\\slot_5 | 2 | 15 | 2 | 13 | 30 |
| data\\hexenwerk\\functions\\wand\\spells | 35 | 184 | 8 | 77 | 269 |
| data\\hexenwerk\\functions\\wand\\spells (Files) | 1 | 8 | 0 | 4 | 12 |
| data\\hexenwerk\\functions\\wand\\spells\\no_raycast | 7 | 40 | 2 | 19 | 61 |
| data\\hexenwerk\\functions\\wand\\spells\\no_raycast (Files) | 1 | 19 | 2 | 5 | 26 |
| data\\hexenwerk\\functions\\wand\\spells\\no_raycast\\spells_effect | 6 | 21 | 0 | 14 | 35 |
| data\\hexenwerk\\functions\\wand\\spells\\no_raycast\\spells_effect (Files) | 4 | 12 | 0 | 13 | 25 |
| data\\hexenwerk\\functions\\wand\\spells\\no_raycast\\spells_effect\\commovus_motus | 2 | 9 | 0 | 1 | 10 |
| data\\hexenwerk\\functions\\wand\\spells\\raycast | 27 | 136 | 6 | 54 | 196 |
| data\\hexenwerk\\functions\\wand\\spells\\raycast (Files) | 6 | 67 | 6 | 23 | 96 |
| data\\hexenwerk\\functions\\wand\\spells\\raycast\\spells_impact | 21 | 69 | 0 | 31 | 100 |
| data\\hexenwerk\\functions\\wand\\spells\\raycast\\spells_impact (Files) | 1 | 3 | 0 | 0 | 3 |
| data\\hexenwerk\\functions\\wand\\spells\\raycast\\spells_impact\\block | 7 | 21 | 0 | 12 | 33 |
| data\\hexenwerk\\functions\\wand\\spells\\raycast\\spells_impact\\block (Files) | 5 | 16 | 0 | 9 | 25 |
| data\\hexenwerk\\functions\\wand\\spells\\raycast\\spells_impact\\block\\consedo | 2 | 5 | 0 | 3 | 8 |
| data\\hexenwerk\\functions\\wand\\spells\\raycast\\spells_impact\\commovus_motus | 2 | 7 | 0 | 0 | 7 |
| data\\hexenwerk\\functions\\wand\\spells\\raycast\\spells_impact\\entity | 6 | 20 | 0 | 16 | 36 |
| data\\hexenwerk\\functions\\wand\\spells\\raycast\\spells_impact\\glacius | 2 | 8 | 0 | 2 | 10 |
| data\\hexenwerk\\functions\\wand\\spells\\raycast\\spells_impact\\terrae_motus | 2 | 8 | 0 | 1 | 9 |
| data\\hexenwerk\\functions\\wand\\spells\\raycast\\spells_impact\\utility | 1 | 2 | 0 | 0 | 2 |
| data\\hexenwerk\\item_modifiers | 17 | 161 | 0 | 17 | 178 |
| data\\hexenwerk\\item_modifiers (Files) | 1 | 6 | 0 | 1 | 7 |
| data\\hexenwerk\\item_modifiers\\attunements | 6 | 85 | 0 | 6 | 91 |
| data\\hexenwerk\\item_modifiers\\attunements\\wand | 6 | 85 | 0 | 6 | 91 |
| data\\hexenwerk\\item_modifiers\\attunements\\wand (Files) | 1 | 15 | 0 | 1 | 16 |
| data\\hexenwerk\\item_modifiers\\attunements\\wand\\slots | 5 | 70 | 0 | 5 | 75 |
| data\\hexenwerk\\item_modifiers\\dev_stone | 4 | 34 | 0 | 4 | 38 |
| data\\hexenwerk\\item_modifiers\\swap_wand_slot | 5 | 30 | 0 | 5 | 35 |
| data\\hexenwerk\\item_modifiers\\update | 1 | 6 | 0 | 1 | 7 |
| data\\hexenwerk\\item_modifiers\\update\\wand | 1 | 6 | 0 | 1 | 7 |
| data\\hexenwerk\\loot_tables | 40 | 679 | 0 | 28 | 707 |
| data\\hexenwerk\\loot_tables\\blocks | 4 | 76 | 0 | 4 | 80 |
| data\\hexenwerk\\loot_tables\\items | 36 | 603 | 0 | 24 | 627 |
| data\\hexenwerk\\loot_tables\\items (Files) | 10 | 199 | 0 | 9 | 208 |
| data\\hexenwerk\\loot_tables\\items\\attunement_shards | 5 | 95 | 0 | 5 | 100 |
| data\\hexenwerk\\loot_tables\\items\\spell_books | 15 | 285 | 0 | 9 | 294 |
| data\\hexenwerk\\loot_tables\\items\\stones | 6 | 24 | 0 | 1 | 25 |
| data\\hexenwerk\\predicates | 21 | 271 | 0 | 21 | 292 |
| data\\hexenwerk\\predicates\\armor | 4 | 44 | 0 | 4 | 48 |
| data\\hexenwerk\\predicates\\armor\\armor_modifiers | 4 | 44 | 0 | 4 | 48 |
| data\\hexenwerk\\predicates\\display | 2 | 86 | 0 | 2 | 88 |
| data\\hexenwerk\\predicates\\flags | 3 | 28 | 0 | 3 | 31 |
| data\\hexenwerk\\predicates\\holding | 8 | 97 | 0 | 8 | 105 |
| data\\hexenwerk\\predicates\\percent | 4 | 16 | 0 | 4 | 20 |
| data\\hexenwerk\\recipes | 3 | 57 | 0 | 6 | 63 |
| data\\hexenwerk\\tags | 10 | 392 | 0 | 1 | 393 |
| data\\hexenwerk\\tags\\biomes | 1 | 32 | 0 | 0 | 32 |
| data\\hexenwerk\\tags\\blocks | 3 | 147 | 0 | 0 | 147 |
| data\\hexenwerk\\tags\\entity_types | 5 | 204 | 0 | 1 | 205 |
| data\\hexenwerk\\tags\\items | 1 | 9 | 0 | 0 | 9 |
| data\\hexenwerk\\worldgen | 4 | 66 | 0 | 3 | 69 |
| data\\hexenwerk\\worldgen\\structure | 1 | 15 | 0 | 1 | 16 |
| data\\hexenwerk\\worldgen\\structure_set | 1 | 14 | 0 | 0 | 14 |
| data\\hexenwerk\\worldgen\\template_pool | 2 | 37 | 0 | 2 | 39 |
| data\\minecraft | 10 | 916 | 0 | 7 | 923 |
| data\\minecraft\\loot_tables | 7 | 903 | 0 | 7 | 910 |
| data\\minecraft\\loot_tables\\blocks | 1 | 23 | 0 | 1 | 24 |
| data\\minecraft\\loot_tables\\chests | 4 | 767 | 0 | 4 | 771 |
| data\\minecraft\\loot_tables\\entities | 2 | 113 | 0 | 2 | 115 |
| data\\minecraft\\tags | 3 | 13 | 0 | 0 | 13 |
| data\\minecraft\\tags\\damage_type | 1 | 7 | 0 | 0 | 7 |
| data\\minecraft\\tags\\functions | 2 | 6 | 0 | 0 | 6 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)