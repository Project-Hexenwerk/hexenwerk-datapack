# Read in the file
with open('C:\\Users\\Flynn\\AppData\\Roaming\\.minecraft\\saves\\Hexenwerk Dev\\datapacks\\Hexenwerk Datapack\\data\\hexenwerk\\functions\\devtest\\display.mcfunction', 'r') as file :
  filedata = file.read()

# Replace the target string
filedata = filedata.replace('001', '016')
filedata = filedata.replace('002', '017')
filedata = filedata.replace('003', '018')

# Write the file out again
with open('C:\\Users\\Flynn\\AppData\\Roaming\\.minecraft\\saves\\Hexenwerk Dev\\datapacks\\Hexenwerk Datapack\\data\\hexenwerk\\functions\\devtest\\display.mcfunction', 'w') as file:
  file.write(filedata)
